<template>
	<div class="carosuel-main">
		<q-carousel animated height="70%" v-model="slide" navigation infinite :autoplay="15000" transition-prev="slide-right" transition-next="slide-left">
			<q-carousel-slide div v-for="(item,index) in carousel_data" :key="index" :name="index" :img-src="item.img">
				<div class="row">
					<div class="col-md-6 flex items-center">
						<div class="asap-font text-white text-h3 q-pa-md image-title carousel-heading">
							{{ item.heading }}</br>
							<div class="text-h5">{{ item.subtitle }}</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="flex justify-end mtt-10">
							<q-card squared class="mbb-30 carosuel-property-card shadow-20 flex items-end ">
								<q-img src="statics/experience.jpg">
									<div class="absolute-bottom text-uppercase text-weight-bolder text-h5 text-left">
										50+ Years of Experience
									</div>
								</q-img>
							</q-card>
						</div>
						<div class="flex justify-end">
							<q-card squared class="mbb-30 carosuel-property-card shadow-20">
								<q-img src="statics/makeinindia.jpg"></q-img>
							</q-card>
						</div>
						<div class="flex justify-end">
							<q-card squared class="mbb-30 carosuel-property-card  shadow-20">
								<q-img src="statics/iso9001.jpg"></q-img>
							</q-card>
						</div>
					</div>
				</div>
			</q-carousel-slide>
		</q-carousel>
	</div>
</template>
<script>
import
{
	firebaseStorage
}
from 'boot/firebase'
export default
{
	data()
	{
		return {
			slide: 1,
			carousel_data: [],
		}

	},
	created()
	{
		let carosuelData = firebaseStorage.collection('carosuel').get()
			.then(querySnapshot =>
			{
				this.carousel_data = querySnapshot.docs.map(doc => doc.data());
			})
			.catch(err =>
			{
				console.log('Error getting document', err);
			});
	}


};

</script>
