<template>
	<q-page padding>
		<div class="flex flex-center text-h4">
			Enquiries
		</div>
		<EnquiryWidget />
		</div>
	</q-page>
</template>
<script>
import EnquiryWidget from './EnquiryWidget.vue'
export default
{
	components:
	{
		EnquiryWidget
	},
};

</script>
