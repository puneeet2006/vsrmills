<template>
	<div class="q-pa-xl">
		<div class="q-pa-md text-center mbb-20 text-h2">
			About
		</div>
		<div class="row justify-center mtt-20">
			<q-card class="bg-white w-85 q-pa-md ">
				<q-card-section class="q-pa-sm text-center text-body1 " style="word-wrap: break-word;">
					<div class="mbb-10 text-center text-grey">
						<q-avatar size="200px">
							<img src="/statics/founder.jpg">
						</q-avatar>
					</div>
					<div class="mbb-30 text-center text-grey text-body1">
						VSR Rolling Mills by founded by <b>Mr. S.S. VAIDYA</b>
					</div>
					VSR Rolling Mills & Machinery Private Limited is an ISO 9001-2008 certified company and a Government of India Recognized EXPORT & Domestic HOUSE, a well - organized & well – equipped Engineering Company situated on the 91 - A Industrial Area No – 1 A.B. Road Indore (India), one of the place consisting maximum number of Copper/Brass/Aluminum/Steel Producing Mills in India.
					<br> </br>
					We are basically catering to the needs of the Copper Mill Industry with our services ranging from Engineering, Consultancy, Design and Development, Manufacturing & Exporting Highly Economical and cost effective Copper/Aluminum Rolling Mill Plants on Turnkey Basis. The Machining & Material Handling Capacity available up to 20 M.T. enables VSR to provide Engineering Assistance to Total Copper/Aluminum Making Industry...
					<br> </br>
					VSR Rolling Mills & Machinery Private Limited is a today a professionally managed company. Set up by, Mr. S.S. VAIDYA
					, VSR Rolling Mills & Machinery Private Limited. is a tribute to the vision and enterprise of his father who set up a small factory to manufacture hand presses after the partition of India in 2010.
					Technical experts with the experience of working at some of India's largest organizations and machine shops work together as an interactive team, pooling their expertise to achieve excellence. VSR Rolling Mills & Machinery Private Limited. believes in enduring partnerships with every customer, so that relationships grow stronger with mutual success growth.
				</q-card-section>
			</q-card>
		</div>
	</div>
</template>
