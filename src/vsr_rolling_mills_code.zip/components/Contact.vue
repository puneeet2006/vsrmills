<template>
	<div class="q-pa-xl">
		<div class="q-pa-md text-center text-h2">
			Contact Us
		</div>
		<div class=" text-center text-grey text-body1">
			We are happy to talk to you!
		</div>
		<div class="row justify-center mtt-20">
			<q-card class="bg-primary text-white w-85 q-pa-lg ">
				<q-card-section>
					<div class="row">
						<div class="col-2">
							<q-icon name="fas fa-id-card-alt"> </q-icon>
						</div>
						<div class="col-auto">
							<div> S.S. VAIDYA </div>
						</div>
					</div>
					<div class="row mtt-20">
						<div class="col-2">
							<q-icon name="fas fa-phone"> </q-icon>
						</div>
						<div class="col-auto">
							<a class="text-white" href="tel:+919826335804">+91-9826335804</a>(Hindi-English Speaking)
						</div>
					</div>
					<div class="row mtt-20">
						<div class="col-2">
							<q-icon name="fas fa-envelope"> </q-icon>
						</div>
						<div class="col-auto">
							<a class="text-white" href="mailto:ssvaidya2002@yahoo.com">ssvaidya2002@yahoo.com</a> |
							<a class="text-white" href="mailto:vsrrollingmills@gmail.com">vsrrollingmills@gmail.com</a>
						</div>
					</div>
					<div class="row mtt-20">
						<div class="col-2">
							<q-icon name="fas fa-building"> </q-icon>
						</div>
						<div class="col-auto">
							Register office : 396 Virat Nagar <br>
							Mushakhedi Indore : 452001 <br>
							Madhya Pradesh (India)<br>
						</div>
					</div>
					<div class="row mtt-20">
						<div class="col-2">
							<q-icon name="fas fa-industry"> </q-icon>
						</div>
						<div class="col-auto">
							Factory Address : 91-A Industrial Area<br>
							A.B. Road Dewas : 455001<br>
							Madhya Pradesh (India)<br>
						</div>
					</div>
					<div class="row mtt-20">
						<div class="col-2">
							<q-icon name="far fa-clock"> </q-icon>
						</div>
						<div class="col-auto">
							Monday – Saturday 9:00 – 18:00
						</div>
					</div>
				</q-card-section>
			</q-card>
		</div>
		<div class="row justify-center mtt-20 ">
			<q-card class="w-85">
				<q-card-section>
					<iframe width="100%" height="400" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJ5x03DIUXYzkRBUXyCcJHKQI&key=AIzaSyA8dtarlka3nTc3y0LrdOUl-2XbaPsVhpI" allowfullscreen></iframe>
				</q-card-section>
			</q-card>
		</div>
	</div>
	</div>
</template>
