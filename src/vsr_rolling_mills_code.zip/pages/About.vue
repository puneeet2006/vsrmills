<template>
	<div>
		<q-page padding>
			<AboutUs />
		</q-page>
	</div>
</template>
<script>
import AboutUs from '../components/AboutUs.vue'

export default
{
	components:
	{
		AboutUs,
	},
	data()
	{
		return {}
	}
};

</script>
