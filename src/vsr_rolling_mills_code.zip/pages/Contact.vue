<template>
	<div>
		<q-page padding>
			<Contact />
		</q-page>
	</div>
</template>
<script>
import Contact from '../components/Contact.vue'
export default
{
	components:
	{
		Contact,
	},
	data()
	{
		return {}
	}
};

</script>
