export function user(state)
{
	return state.user
}


export function getEnqFormShowStatus(state)
{
	return state.enq_form_show;
}

export function getEnqFormSubmittedStatus(state)
{
	return state.enq_form_submitted;
}
