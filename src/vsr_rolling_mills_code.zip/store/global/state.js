export default
{
	user:
	{
		loggedIn: false,
		data: null,
	},
	enq_form_show: true,
	enq_form_submitted: false,
}
